/*
Production helper snippets for Sulap Artisan.
Use these when replacing demo actions with Supabase writes.
Assumes your page already has:
  const db = window.supabase.createClient(window.SULAP_SUPABASE_URL, window.SULAP_SUPABASE_ANON_KEY)
*/

async function getCurrentProfile() {
  const { data: { user }, error: userError } = await db.auth.getUser();
  if (userError || !user) return null;
  const { data, error } = await db.from('profiles').select('*').eq('user_id', user.id).single();
  if (error) throw error;
  return data;
}

async function signInAdmin(email, password) {
  const { error } = await db.auth.signInWithPassword({ email, password });
  if (error) throw error;
  const profile = await getCurrentProfile();
  if (!profile || profile.role !== 'admin') throw new Error('This account is not an admin.');
  return profile;
}

async function signInVendor(email, password) {
  const { error } = await db.auth.signInWithPassword({ email, password });
  if (error) throw error;
  const profile = await getCurrentProfile();
  if (!profile || profile.role !== 'vendor') throw new Error('This account is not a vendor.');
  return profile;
}

async function signOut() {
  await db.auth.signOut();
}

function safeFileName(name) {
  return String(name).toLowerCase().replace(/[^a-z0-9.\-_]+/g, '-');
}

async function uploadSulapFile({ bucket, file, vendorRefId, eventId, fileType }) {
  const prefix = vendorRefId || 'general';
  const path = `${prefix}/${eventId || 'site'}/${Date.now()}-${safeFileName(file.name)}`;
  const { error: uploadError } = await db.storage.from(bucket).upload(path, file, { upsert: false });
  if (uploadError) throw uploadError;

  let publicUrl = null;
  if (['logos', 'event-images', 'product-photos'].includes(bucket)) {
    const { data } = db.storage.from(bucket).getPublicUrl(path);
    publicUrl = data.publicUrl;
  }

  const { error: fileError } = await db.from('files').insert({
    owner_vendor_ref_id: vendorRefId || null,
    event_id: eventId || null,
    file_type: fileType,
    storage_bucket: bucket,
    storage_path: path,
    public_url: publicUrl
  });
  if (fileError) throw fileError;

  return { bucket, path, publicUrl };
}

async function createSignedDownloadUrl(bucket, path) {
  const { data, error } = await db.storage.from(bucket).createSignedUrl(path, 60 * 10);
  if (error) throw error;
  return data.signedUrl;
}

async function createEventInSupabase(form) {
  const eventId = `E${Date.now()}`;
  const { error } = await db.from('events').insert({
    id: eventId,
    name: form.name,
    date_start: form.dateStart,
    date_end: form.dateEnd,
    time_text: form.timeText,
    venue: form.venue,
    fee_fnb: form.feeFnb,
    fee_nonfnb: form.feeNonFnb,
    status: 'active',
    description: form.description,
    image_url: form.imageUrl || null
  });
  if (error) throw error;
  return eventId;
}

async function saveParkingSerialToSupabase(eventId, vendorRefId, dayIndex, serialNo) {
  const { error } = await db.from('parking_records').upsert({
    event_id: eventId,
    vendor_ref_id: vendorRefId,
    day_index: dayIndex,
    serial_no: serialNo,
    updated_at: new Date().toISOString()
  }, { onConflict: 'event_id,vendor_ref_id,day_index' });
  if (error) throw error;
}

async function saveVendorPassToSupabase(record) {
  const { error } = await db.from('vendor_passes').upsert({
    event_id: record.eventId,
    vendor_ref_id: record.vendorRefId,
    collected_by: record.collectedBy,
    collector_phone: record.collectorPhone,
    tags_issued: record.tagsIssued,
    collected_on: record.collectedOn || null,
    tags_returned: record.tagsReturned,
    returned_on: record.returnedOn || null,
    updated_at: new Date().toISOString()
  }, { onConflict: 'event_id,vendor_ref_id' });
  if (error) throw error;
}

async function updateEventApplicationStatus(eventId, vendorRefId, status) {
  const { error } = await db.from('event_applications')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('event_id', eventId)
    .eq('vendor_ref_id', vendorRefId);
  if (error) throw error;
}
