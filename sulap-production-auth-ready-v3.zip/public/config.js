// Fill this in after you create your Supabase project.
// Supabase Dashboard → Project Settings → API
window.SULAP_SUPABASE_URL = 'PASTE_YOUR_SUPABASE_PROJECT_URL_HERE';
window.SULAP_SUPABASE_ANON_KEY = 'PASTE_YOUR_SUPABASE_ANON_PUBLIC_KEY_HERE';
