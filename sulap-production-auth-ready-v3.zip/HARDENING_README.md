# Sulap Artisan — Production Hardening Phase

This phase locks down the Supabase database and prepares your system for real admin/vendor accounts and private receipts/invoices.

## What this phase does

- Adds Supabase Auth roles: `admin` and `vendor`
- Adds a `profiles` table
- Restricts database access with Row Level Security
- Keeps homepage/event public data readable
- Makes receipts and invoices private
- Allows vendors to read only their own records
- Allows admins to manage events, vendors, applications, payments, parking, passes, and settings

Supabase recommends using Row Level Security for browser-accessed data, and Storage uses RLS policies on `storage.objects` for upload/read control.

## Files added

```text
database/hardening/
  01-production-rls-auth-storage.sql
  02-create-first-admin-template.sql
  03-link-vendor-user-template.sql
snippets/
  supabase-auth-and-storage-helpers.js
```

## Run order

### 1. Make sure the original schema has already been run

Run this first if you have not already:

```text
database/supabase-schema.sql
```

### 2. Run the hardening SQL

In Supabase:

```text
SQL Editor → New query
```

Paste and run:

```text
database/hardening/01-production-rls-auth-storage.sql
```

### 3. Create your first admin login

In Supabase:

```text
Authentication → Users → Add user
```

Create your admin email/password.

Then copy the user UUID.

Open:

```text
database/hardening/02-create-first-admin-template.sql
```

Replace:

```text
PASTE_ADMIN_USER_UUID_HERE
your-admin-email@example.com
```

Run it in SQL Editor.

### 4. Link vendor accounts

For each vendor who needs portal login:

1. Create user in `Authentication → Users`
2. Copy the UUID
3. Run `03-link-vendor-user-template.sql` with that vendor's ref ID

Example vendor ref:

```text
SUL-2025-0038
```

### 5. Update app login screens

Your current HTML still has demo-style login fields. Replace the demo login functions with the helper functions in:

```text
snippets/supabase-auth-and-storage-helpers.js
```

Admin should log in with:

```js
await signInAdmin(email, password)
```

Vendor should log in with:

```js
await signInVendor(email, password)
```

### 6. Private storage paths

Use this path pattern for private vendor files:

```text
SUL-2025-0038/E001/filename.pdf
```

This lets the RLS policy verify that a vendor only opens files under their own vendor reference ID.

Recommended bucket use:

```text
logos          public
event-images   public
product-photos public
receipts       private
invoices       private
```

### 7. Signed URLs for receipts/invoices

Because receipts/invoices are private, do not use public URLs. Use signed URLs:

```js
const url = await createSignedDownloadUrl('invoices', storagePath)
window.open(url, '_blank')
```

## Important notes before public launch

- Do not put the `service_role` key in `config.js`.
- Only use the anon public key in the frontend.
- Test with one admin and one vendor account before sharing the site publicly.
- After hardening, demo login by reference ID will stop working unless replaced with real Supabase Auth login.

