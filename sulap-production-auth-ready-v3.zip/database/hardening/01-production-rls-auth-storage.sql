-- Sulap Artisan production hardening: Auth roles, RLS, and private storage
-- Run AFTER the original database/supabase-schema.sql.
-- Supabase Dashboard → SQL Editor → New query → paste → Run.

create extension if not exists pgcrypto;

-- 1) User profile / role table
create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','vendor')) default 'vendor',
  vendor_ref_id text unique references public.vendors(ref_id) on delete set null,
  full_name text,
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 2) Helper functions for policies
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where user_id = auth.uid()
    and role = 'admin'
  );
$$;

create or replace function public.my_vendor_ref_id()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select vendor_ref_id from public.profiles
  where user_id = auth.uid()
  limit 1;
$$;

-- 3) Add/keep useful indexes
create index if not exists profiles_role_idx on public.profiles(role);
create index if not exists vendors_user_id_idx on public.vendors(user_id);
create index if not exists event_applications_vendor_idx on public.event_applications(vendor_ref_id);
create index if not exists payments_vendor_idx on public.payments(vendor_ref_id);
create index if not exists parking_vendor_idx on public.parking_records(vendor_ref_id);
create index if not exists vendor_passes_vendor_idx on public.vendor_passes(vendor_ref_id);

-- 4) Remove temporary public policies from MVP schema
-- site_settings
drop policy if exists "temporary public update site settings" on public.site_settings;
drop policy if exists "temporary public upsert site settings" on public.site_settings;
-- vendors
drop policy if exists "public can read demo vendors" on public.vendors;
drop policy if exists "public can apply as vendor" on public.vendors;
-- events
drop policy if exists "temporary public manage events" on public.events;
-- event applications
drop policy if exists "public can read event applications" on public.event_applications;
drop policy if exists "public can insert event applications" on public.event_applications;
drop policy if exists "temporary public manage applications" on public.event_applications;
-- payments
drop policy if exists "public can read payments" on public.payments;
drop policy if exists "temporary public manage payments" on public.payments;
-- parking
drop policy if exists "public can read parking" on public.parking_records;
drop policy if exists "temporary public manage parking" on public.parking_records;
-- passes
drop policy if exists "public can read vendor passes" on public.vendor_passes;
drop policy if exists "temporary public manage vendor passes" on public.vendor_passes;
-- files
drop policy if exists "public can read files" on public.files;

-- 5) Enable RLS everywhere
alter table public.profiles enable row level security;
alter table public.site_settings enable row level security;
alter table public.vendors enable row level security;
alter table public.events enable row level security;
alter table public.event_applications enable row level security;
alter table public.payments enable row level security;
alter table public.parking_records enable row level security;
alter table public.vendor_passes enable row level security;
alter table public.files enable row level security;

-- 6) Profiles policies
create policy "profiles: user reads own profile" on public.profiles
for select to authenticated
using (user_id = auth.uid() or public.is_admin());

create policy "profiles: admin manages all" on public.profiles
for all to authenticated
using (public.is_admin())
with check (public.is_admin());

-- 7) Site settings policies
-- Public can read branding/homepage text.
drop policy if exists "public can read site settings" on public.site_settings;
create policy "site_settings: public read" on public.site_settings
for select using (true);

create policy "site_settings: admin write" on public.site_settings
for all to authenticated
using (public.is_admin())
with check (public.is_admin());

-- 8) Events policies
-- Public/vendor can read active events. Admin can read/manage all.
drop policy if exists "public can read active events" on public.events;
create policy "events: public read active" on public.events
for select using (status = 'active' or public.is_admin());

create policy "events: admin manage" on public.events
for all to authenticated
using (public.is_admin())
with check (public.is_admin());

-- 9) Vendor policies
-- New public applications are allowed, but reading/updating is restricted.
create policy "vendors: public insert application" on public.vendors
for insert with check (status = 'pending');

create policy "vendors: admin read all, vendor read own" on public.vendors
for select to authenticated
using (public.is_admin() or ref_id = public.my_vendor_ref_id() or user_id = auth.uid());

create policy "vendors: admin update all, vendor update own" on public.vendors
for update to authenticated
using (public.is_admin() or ref_id = public.my_vendor_ref_id() or user_id = auth.uid())
with check (public.is_admin() or ref_id = public.my_vendor_ref_id() or user_id = auth.uid());

create policy "vendors: admin delete" on public.vendors
for delete to authenticated
using (public.is_admin());

-- 10) Event application policies
create policy "event_applications: admin all, vendor own read" on public.event_applications
for select to authenticated
using (public.is_admin() or vendor_ref_id = public.my_vendor_ref_id());

create policy "event_applications: vendor apply own" on public.event_applications
for insert to authenticated
with check (public.is_admin() or vendor_ref_id = public.my_vendor_ref_id());

create policy "event_applications: admin update" on public.event_applications
for update to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "event_applications: admin delete" on public.event_applications
for delete to authenticated
using (public.is_admin());

-- 11) Payments / invoices policies
create policy "payments: admin all, vendor own read" on public.payments
for select to authenticated
using (public.is_admin() or vendor_ref_id = public.my_vendor_ref_id());

create policy "payments: admin insert" on public.payments
for insert to authenticated
with check (public.is_admin());

create policy "payments: admin update or vendor own receipt upload" on public.payments
for update to authenticated
using (public.is_admin() or vendor_ref_id = public.my_vendor_ref_id())
with check (public.is_admin() or vendor_ref_id = public.my_vendor_ref_id());

create policy "payments: admin delete" on public.payments
for delete to authenticated
using (public.is_admin());

-- 12) Parking policies
create policy "parking_records: admin all, vendor own read" on public.parking_records
for select to authenticated
using (public.is_admin() or vendor_ref_id = public.my_vendor_ref_id());

create policy "parking_records: admin manage" on public.parking_records
for all to authenticated
using (public.is_admin())
with check (public.is_admin());

-- 13) Vendor pass policies
create policy "vendor_passes: admin all, vendor own read" on public.vendor_passes
for select to authenticated
using (public.is_admin() or vendor_ref_id = public.my_vendor_ref_id());

create policy "vendor_passes: admin manage" on public.vendor_passes
for all to authenticated
using (public.is_admin())
with check (public.is_admin());

-- 14) Files table policies
create policy "files: admin all, vendor own read" on public.files
for select to authenticated
using (public.is_admin() or owner_vendor_ref_id = public.my_vendor_ref_id());

create policy "files: authenticated insert own/admin" on public.files
for insert to authenticated
with check (public.is_admin() or owner_vendor_ref_id = public.my_vendor_ref_id());

create policy "files: admin update delete" on public.files
for all to authenticated
using (public.is_admin())
with check (public.is_admin());

-- 15) Storage buckets: keep logo and event images public, make sensitive docs private.
update storage.buckets set public = true where id in ('logos','event-images','product-photos');
update storage.buckets set public = false where id in ('receipts','invoices');

-- Clear old storage policies that may conflict.
drop policy if exists "storage: public read public sulap buckets" on storage.objects;
drop policy if exists "storage: authenticated upload sulap files" on storage.objects;
drop policy if exists "storage: admin manage all sulap files" on storage.objects;
drop policy if exists "storage: vendor read own private docs" on storage.objects;

-- Public read for non-sensitive public assets.
create policy "storage: public read public sulap buckets"
on storage.objects for select
using (bucket_id in ('logos','event-images','product-photos'));

-- Authenticated users can upload to the relevant buckets. App code must write paths with vendor_ref_id prefixes for vendor files.
create policy "storage: authenticated upload sulap files"
on storage.objects for insert
to authenticated
with check (bucket_id in ('logos','event-images','product-photos','receipts','invoices'));

-- Admins can manage all Sulap storage files.
create policy "storage: admin manage all sulap files"
on storage.objects for all
to authenticated
using (public.is_admin() and bucket_id in ('logos','event-images','product-photos','receipts','invoices'))
with check (public.is_admin() and bucket_id in ('logos','event-images','product-photos','receipts','invoices'));

-- Vendor can read private docs only when object path starts with their vendor ref, e.g. SUL-2025-0038/receipt.pdf
create policy "storage: vendor read own private docs"
on storage.objects for select
to authenticated
using (
  bucket_id in ('receipts','invoices')
  and split_part(name, '/', 1) = public.my_vendor_ref_id()
);

