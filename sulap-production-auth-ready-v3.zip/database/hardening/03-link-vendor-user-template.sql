-- Link a vendor login account to a vendor application.
-- 1) Create vendor user in Authentication → Users.
-- 2) Copy user UUID.
-- 3) Replace values below.

insert into public.profiles (user_id, role, vendor_ref_id, full_name, email)
values (
  'PASTE_VENDOR_USER_UUID_HERE',
  'vendor',
  'SUL-2025-0038',
  'Vendor Name',
  'vendor-email@example.com'
)
on conflict (user_id) do update set
  role = 'vendor',
  vendor_ref_id = excluded.vendor_ref_id,
  full_name = excluded.full_name,
  email = excluded.email,
  updated_at = now();

update public.vendors
set user_id = 'PASTE_VENDOR_USER_UUID_HERE'
where ref_id = 'SUL-2025-0038';
