-- Create/link your first admin profile.
-- 1) In Supabase Dashboard → Authentication → Users, create an admin user first.
-- 2) Copy that user's UUID.
-- 3) Replace the values below, then run this SQL.

insert into public.profiles (user_id, role, full_name, email)
values (
  'PASTE_ADMIN_USER_UUID_HERE',
  'admin',
  'Sulap Admin',
  'your-admin-email@example.com'
)
on conflict (user_id) do update set
  role = 'admin',
  full_name = excluded.full_name,
  email = excluded.email,
  updated_at = now();
